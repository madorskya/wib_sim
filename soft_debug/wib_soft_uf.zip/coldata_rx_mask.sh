# single FEMB connected to input 4 on test board
devmem 0xa00c0008 32 0xfff0

