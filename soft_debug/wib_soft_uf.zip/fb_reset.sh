echo 'reset frame builder'
devmem 0xa00c0004 32 0x1020
devmem 0xa00c0004 32 0x0020

