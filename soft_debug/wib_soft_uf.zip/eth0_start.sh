ifconfig eth0 192.168.1.8 netmask 255.255.255.0 up
ip route add 192.168.8.1/24 dev eth0


