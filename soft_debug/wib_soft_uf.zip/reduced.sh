#./coldata_power_off.sh
#./rx_timing_sel_sfp_si5344.sh
clock/si5345_config
#voltages/wib_voltages
#./coldata_power_on.sh
