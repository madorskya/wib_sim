#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <fstream>
#include <sys/mman.h>
#include <fcntl.h>
#include <stdio.h>

#include "femb.h"

using namespace std;

int main (int argc, char * argv[])
{


	FEMB* femb = new FEMB(0); // FEMB number as parameter

	

	int reg3;

	// chip_num_on_FEMB=(0|1), chip_addr, reg_page, reg_addr, [value]
	// chip addresses: 
	// COLDATA = 2 (always)
	// ADC:  4, 5, 6, 7
	// ADC: 12,13,14,15 (maybe)

	int i, j;
	unsigned char d = 0x1b;
	if (argc == 4)
	{
		printf ("programming test pattern\n");
		for (i = 1; i >= 0; i--)
		{
			for (j = 4; j <= 7; j++ )
			{

				d = femb->i2c_read (i, j, 1, 0x89);
				d |= 0x10; // adc test pattern
				femb->i2c_write_verify (i, j, 1, 0x89, d);
				printf ("chip: %d adc: %d reg89: %x\n", i, j, d);

				d = femb->i2c_read (i, j, 1, 0xb2);
				d &= ~0x20; // normal output
				femb->i2c_write_verify (i, j, 1, 0xb2, d);
				printf ("chip: %d adc: %d regb2: %x\n", i, j, d);
			}
		}
	}
	else
	if (argc == 3)
	{
		printf ("configuring coldadc\n");
		femb->i2c_write (0, 2, 0, 0x20, 0x5); // ACT = COLDADC reset
		femb->i2c_write (1, 2, 0, 0x20, 0x5); // ACT = COLDADC reset
		femb->fast_cmd(FAST_CMD_EDGE_ACT); // EDGE+ACT command
		femb->configure_coldadc();
	}
	else
	if (argc == 2)
	{
		int wr_data = strtol(argv[1], NULL, 16);
		printf ("writing\n");
		for (i = 1; i >= 0; i--)
		{
			for (j = 4; j <= 7; j++ )
			{
				femb->i2c_write_verify (i, j, 1, 0x9e, wr_data + j);	
				printf ("\n");
			}
		}
	}
	else
	{
		for (i = 0; i < 2; i++) // COLDATA chip
		{
			for (j = 4; j <= 7; j++ ) // ADC address
			{
				reg3 = femb->i2c_read  (i, j, 1, 0x9e);	
				printf("chip: %d vrefp_ctrl = %x\n",j,reg3);
			}
			//		for (j = 12; j <= 15; j++ )
			//		{
			//			reg3 = femb->i2c_read  (i, j, 1, 0x80);	
			//			printf("chip: %d vrefp_ctrl = %x\n",j,reg3);
			//		}
		}
	}


}

